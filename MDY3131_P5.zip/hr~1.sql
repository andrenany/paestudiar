DECLARE
reg_paciente paciente%ROWTYPE;
v_blob blob;
v_bfile bfile;
v_existe_archivo number(2);
v_directorio VARCHAR2(20);
v_foto VARCHAR2(20);
v_id_min_pac NUMBER(5);
v_id_max_pac NUMBER(5);
BEGIN
   SELECT MIN(id_paciente), MAX(id_paciente)
     INTO v_id_min_pac, v_id_max_pac
     FROM paciente;
   WHILE v_id_min_pac <= v_id_max_pac LOOP
     SELECT * 
       INTO reg_paciente
       FROM paciente 
       WHERE id_paciente=v_id_min_pac FOR UPDATE;
-- El bloque contin�a en la siguiente PPT
v_blob:=reg_paciente.foto_paciente;
-- Se genera el nombre del archive jpg seg�n el id de paciente que se lee en el loop
        v_foto:= reg_paciente.id_paciente || '.jpg';
        v_bfile:= BFILENAME ('DIR_FOTOS_PACIENTES',v_foto);
-- Se verifica si el archivo jpg existe en la la carpeta. -- retorna 0=No existe, 1=existe
        v_existe_archivo:= DBMS_LOB.FILEEXISTS(v_bfile); 
IF v_existe_archivo = 1 THEN
           DBMS_LOB.FILEOPEN(v_bfile, DBMS_LOB.FILE_READONLY);
           DBMS_LOB.LOADFROMFILE(v_blob,v_bfile, DBMS_LOB.GETLENGTH(v_bfile));
           DBMS_LOB.FILECLOSE(v_bfile);
        END IF;
     v_id_min_pac:=v_id_min_pac+10;
   END LOOP;
END;
