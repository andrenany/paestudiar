DECLARE
v_blob BLOB; -- almacena el valor de la columna BLOB de la tabla
v_bfile BFILE; -- almacenar el archivo binario que se desea cargar en la BD
BEGIN
  -- Se inserta una fila a la tabla y en la columna foto_paciente el valor ser� VACIO
  INSERT INTO PACIENTE
         VALUES(10,'Juan Antonio P�rez Soto',EMPTY_BLOB())
  RETURNING foto_paciente INTO v_blob;
  --  A la variable v_bfile se le asigna la ruta y nombre del archive jpg que se desea cargar
  v_bfile:=BFILENAME('DIR_FOTOS_PACIENTES','10.jpg');
  -- Se abre el archivo jpg de modo lectura
  DBMS_LOB.OPEN(v_bfile,DBMS_LOB.LOB_READONLY);
  -- Se carga el archivo jpg en la columna de tabla para primera fila que se insert�
  DBMS_LOB.LOADFROMFILE(v_blob,v_bfile,DBMS_LOB.GETLENGTH(v_bfile));
  -- Se cierra el archivo jpg que ley�
  DBMS_LOB.CLOSE(v_bfile);
  COMMIT;
  -- Se insertan el resto de filas en la tabla pero con la columna foto_paciente vac�a
  INSERT INTO PACIENTE
  VALUES(20,'Mar�a P�a Santander Toro',EMPTY_BLOB());
  INSERT INTO PACIENTE
         VALUES(30,'Patricia Sep�lveda Arias',EMPTY_BLOB());
COMMIT;
END;
